import dashboard from "./dashboard.svg";
import students from "./students.svg";
import teacher from "./teacher.svg";
import transaction from "./transactions.svg";
import course from "./course.svg";
import watch from "./images/watch.png";
import logo from "./images/NextStep.svg";

export { dashboard, students, teacher, transaction, course, watch, logo };
