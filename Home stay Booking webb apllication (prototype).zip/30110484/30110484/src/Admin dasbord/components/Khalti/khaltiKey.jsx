let myKey ={
    publicTestKey:'test_public_key_d577b97ec4b54691a1abfeef62a5218e',
    secretKey:'test_secret_key_c9509c35a585441887dede250864c05e'
}

export default myKey;