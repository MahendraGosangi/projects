export const navbar = [
  {
    id: 1,
    label: "Home",
    url: "/",
  },
  {
    id: 2,
    label: "About",
    url: "/about",
  },
  {
    id: 3,
    label: "Host",
    url: "/host",
  },
  {
    id: 4,
    label: "Services",
    url: "/service",
  },
  {
    id: 4,
    label: "Contact",
    url: "/contact",
  },
];
