import React from "react";
import Navbar from "../Navbar";
import Herosection from "./herosection";

const Contact = () => {
  return (
    <div>
      <Herosection />
    </div>
  );
};

export default Contact;
