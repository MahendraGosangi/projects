import home1 from "./homePagePhoto.jpeg";  
import home2 from "./homepagephoto2.jpeg";
import locationIcon from "./locationicon.svg";
import logo from "./actuallogo.png";
import logoHeader from "./white.jpeg";
import activityimage from "./featuredphoto1.jpeg";
import activityimage2 from "./featuredphoto2.jpeg";
import activityimage3 from "./featuredphoto3.jpeg";
import activityimage4 from "./featuredphoto4.jpeg";
import nature from "./Welcome to Topas Ecolodge - Mountaintop Resort in Sapa Vietnam.jpg";
import car from "./car.jpg";
import laundry from "./loundryy.png";
import wifi from "./internet.png";
import pool from "./pool.png";
import breakfast from "./breakfasticon.png";
import housekeeping from "./housekeep.png";
import swimming from "./swimming.webp";
import service from "./service.jpg";
import delux from "./deluxroom.jpg";
import double from "./double room.jpg";
import luxury from "./luxury room.jpg";
import bed from "./bed.png";
import guest from "./guests.png";
import bathroom from "./bathroom.png";
import facebook from "./facebook.svg";
import instagram from "./instagram.svg";
import linkedin from "./linkedin.svg";
import twitter from "./twitter.svg";
import dolor from "./dolor.svg";
import balance from "./balanve.svg";
import watch from "./watch.svg";
import shield from "./shield.svg";
import trek from "./treck.avif";
import background from "./gann.jpg";
import temple from "./temple.jpg";
import image1 from "./image 1.jpg";
import image2 from "./image 2.jpg";
import image3 from "./image 3.jpg";
import image4 from "./image 4.jpg";
import image5 from "./image 5.jpg";
import image6 from "./image 6.jpg";
import image7 from "./image 7.jpg";
import aboutus from "./aboutus.jpg";

export {
  home1,
  home2,
  locationIcon,
  logo,
  activityimage,
  activityimage2,
  activityimage3,
  activityimage4,
  car,
  laundry,
  wifi,
  pool,
  breakfast,
  housekeeping,
  swimming,
  service,
  delux,
  double,
  luxury,
  guest,
  bed,
  bathroom,
  facebook,
  instagram,
  linkedin,
  twitter,
  nature,
  dolor,
  shield,
  watch,
  balance,
  trek,
  background,
  temple,
  image1,
  image3,
  image2,
  image4,
  image5,
  image6,
  image7,
  aboutus,
  logoHeader,
};
