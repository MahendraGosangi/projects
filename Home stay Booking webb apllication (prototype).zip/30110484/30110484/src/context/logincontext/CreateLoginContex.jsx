import { createContext } from "react";

const LoginContex = createContext();

export default LoginContex;
