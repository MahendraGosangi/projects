const webApi = {
    apiUrl : "https://9c01-2400-1a00-b060-9bc9-8dbc-101b-722-5dd2.ngrok-free.app"
}
export default webApi;